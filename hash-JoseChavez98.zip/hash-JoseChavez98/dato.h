#ifndef dato_h
#define dato_h

#include <iostream>

class Dato {
 private:
  std::string zip;
  std::string phoneNumber;
  std::string name;

 public:
  Dato() = default;

  Dato(std::string zip, std::string phoneNumber, std::string name) {
    this->zip = zip;
    this->phoneNumber = phoneNumber;
    this->name = name;
  }
  ~Dato() = default;

  std::string get_zip() {
    return zip;
  }

  void describe() {
    std::cout << "zip: " << this->zip << "  " << "phone: " << this->phoneNumber << "  " << "name: " << this->name
              << std::endl;
  }
};

#endif