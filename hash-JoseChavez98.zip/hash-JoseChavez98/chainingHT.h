#ifndef chainingHt_H
#define chainingHt_H

#include "hashTable.h"
#include <map>
#include "linkedList.hpp"

class ChainingHT : public HashTable {
 private:
  std::map<int, LinkedList<Dato>> hashTable;
 public:

  void insert(Dato dato) override {
    int key =hashFunction(dato.get_zip());
    hashTable[key].push_back(dato);
  }
  void errase(std::string zip) override {
    int key=hashFunction(zip);
    hashTable[key].delete_node(zip);
  }
  Dato search(std::string zip) override {
    std::cout<<"entre";
    int key=hashFunction(zip);
    hashTable[key].search(zip).describe();
  }
  void describe() {
    for(auto &i : hashTable){
      i.second.describe();
      std::cout<<'\n';
    }
  }

};

#endif
