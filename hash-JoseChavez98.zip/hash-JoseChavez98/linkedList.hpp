
#ifndef linkedList_h
#define linkedList_h

#include <iostream>
#include "list.h"
#include "list_iterator.hpp"

namespace cs2100 {

template <class AnyObject>
class ForwardIterator;

template <class AnyObject>
class LinkedList final : List<AnyObject> {
 public:
  struct Node {
    AnyObject value;
    Node * pointer;
  };

 private:
  Node * head = nullptr;
  Node * tail = nullptr;

 public:


  LinkedList() = default;
  ~LinkedList() = default;

  Node * getHead () { return head; }
  Node * getTail () { return tail; }

  void push_front (AnyObject value) {
    if(head== nullptr){
      auto *newnode= new Node{value, nullptr};
      head=newnode;
      tail=newnode;
    }else{
      auto newnode= new Node{value, head};
      head=newnode;
    }
  }

  void push_back (AnyObject value) {
    auto *newnode= new Node{value, nullptr};
    if(head== nullptr && tail== nullptr){
    head=newnode;
    tail=newnode;}
    else{
      tail->pointer=newnode;
      tail=newnode;
    }
  }

  void pop_front() {
    if(head!= nullptr and tail!= nullptr){if(head!=tail){
        //  std::cout<<" "<< head->value<<" ";
        // std::cout<<'\n';
        Node *puntero=head;

        head=head->pointer;

        delete (puntero);}
      else{Node *punt=head;
        head= nullptr;
        tail=nullptr;
        delete punt;

      }


    }
  }

  void pop_back() {
    if(head!= nullptr and tail!= nullptr){if(head!=tail){Node *puntero=head;
        auto *punteroantes=new Node;
        while(puntero->pointer!= nullptr){
          punteroantes=puntero;
          puntero=puntero->pointer;
        }
        tail=punteroantes;
        punteroantes->pointer= nullptr;
        delete puntero;
      }else{
        Node *punt=head;
        head= nullptr;
        tail=nullptr;
        delete punt;
      }}
  }

  inline void describe () {
    std::cout << "List:" << ((!head) ? " (empty)": " ");
    for ( Node * current = head ; current != nullptr ; current = current->pointer ) {
      std::cout << current->value.get_zip() << " ";
    }
    std::cout << "\n";
  }

  void delete_node(std::string key) {
    Node *container= nullptr;
    for ( Node * current = head ; current != nullptr ; current = current->pointer ) {
      if(current->value.get_zip()==key){
        if(container== nullptr){
          head=current->pointer;
        }
        else if(current->value.get_zip()==tail->value.get_zip()){
          container->pointer=current->pointer;
          tail=container;
        }
        else{
          container->pointer=current->pointer;
        }
      }
      else{
        container=current;
      }
    }
  }

  AnyObject search(std::string key) {

    for ( Node * current = head ; current != nullptr ; current = current->pointer ) {
      if(current->value.get_zip()==key){
        return current->value;
      }
    }
  }
};

}

template <class AnyObject>
using LinkedList = cs2100::LinkedList<AnyObject>;

#endif /* linkedList_h */