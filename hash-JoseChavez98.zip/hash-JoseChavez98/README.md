# Hash data structure

Build a hash data structure to simulate a 3 where every entry is a structure that contains a zip code ("AZ"), phone number, and name. Implement the functions `insert`, `delete` and `search`, this operations are based on the zip code which is a set of 2 characters from the alphabet.

**Notes:**

- You should propose a hash functions and its recommended to pass it as a template parameter. 
- Also you should consider all the possible permutations of the zip code in order to avoid overflow and crash.

## Collisions

Implement two collision methods:
- Chaining
- Linear Open Access

`TIP`: You can implement two classes that inherit from a parent hash data structure. Each class should contain a different collision method.
