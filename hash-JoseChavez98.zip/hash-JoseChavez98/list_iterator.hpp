#ifndef list_iterator_h
#define list_iterator_h

#include "linkedList.hpp"

namespace cs2100 {
template <class AnyObject>
class LinkedList;

template <class AnyObject>
class ForwardIterator {
 private:
  typedef typename LinkedList<AnyObject>::Node Node;

  Node * current;

 public:
  ForwardIterator () = default;

  explicit ForwardIterator(Node *node) {
    this->current = node;
  }

  Node *get_node() {
    return current;
  }

  ForwardIterator operator++() {
    this->current = this->current->pointer;
  }
};
}

#endif /* listIterator_h
};
}

#endif /* listIterator_h */