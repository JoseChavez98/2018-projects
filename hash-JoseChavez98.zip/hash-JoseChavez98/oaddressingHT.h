#ifndef oaddressingHT_H
#define oaddressingHT_H

#include "hashTable.h"

class OaddressingHt : public HashTable {
 private:
  Dato hashTable[729];
 public:
  

  void insert(Dato newDato) {

  }
  void errase(std::string zip) {

  }
  Dato search(std::string zip) {

  }

};

#endif
