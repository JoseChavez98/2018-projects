#include "chainingHT.h"



int main() {
  ChainingHT hashTable;
  Dato a("AZ", "988606066", "JOSE");
  Dato b("bd", "988606066", "CARMEN");
  Dato c("db", "988606066", "LUCHA");
  hashTable.insert(b);
  hashTable.insert(a);
  hashTable.insert(c);
  hashTable.search("bd");
  hashTable.errase("bd");
  hashTable.describe();



  return 0;
}

