#ifndef hasTable_h
#define hasTable_h

#include "dato.h"
#include <iostream>

class HashTable {
 public:
  virtual int hashFunction(std::string key) {
    int hashCode = 0;
    for (auto &i : key) {
      hashCode += i;
    }
    return hashCode;
  }

  virtual void insert(Dato)=0;
  virtual void errase(std::string)=0;
  virtual Dato search(std::string)=0;

};

#endif
