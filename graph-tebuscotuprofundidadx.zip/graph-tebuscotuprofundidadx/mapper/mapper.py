from gmplot import gmplot
import os
import sys
import OSMParser as osm
import networkx as nx

limit_left      = -77.04231
limit_bottom    = -12.10543
limit_right     = -77.03233
limit_top       = -12.09919

dir_path    = os.path.dirname(os.path.realpath(__file__))

if len(sys.argv) == 1:
    print("You need to provide one option: [fetch|path]")
    exit()

if sys.argv[1] == "fetch":
    output_file = open(dir_path + "/output/region_graph.txt", "w")
    graph       = osm.read_osm(osm.download_osm(limit_left, limit_bottom, limit_right, limit_top))
    google_map  = gmplot.GoogleMapPlotter( (limit_top + limit_bottom) / 2.0, (limit_left + limit_right) / 2.0, 18, 'AIzaSyCPYUnvfoim1Kt8PlHwN2X3h_hTxShz0mM')

    output_file.write(str(len(graph.nodes)) + "\n" )

    for node_id in graph.nodes:
        node                = graph.nodes[node_id]
        vertices_latitudes  = [float(node['lat'])]
        vertices_longitudes = [float(node['lon'])]
        output_file.write( node_id + " " + str(node['lat']) + " " + str(node['lon']) + "\n")
        google_map.scatter(vertices_latitudes, vertices_longitudes, '#3B0B39', size=4, marker=False)

    for u,v,distance in graph.edges(data=True):
        latitudes   = [graph.node[u]['lat'], graph.node[v]['lat']]
        longitudes  = [graph.node[u]['lon'], graph.node[v]['lon']]
        distance    = distance['length']
        output_file.write( u + " " + v + " " + str(distance) + "\n")
        google_map.plot(latitudes,longitudes,'cornflowerblue', edge_width=3)

    google_map.draw(dir_path + "/output/region_map.html")

elif sys.argv[1] == "path":
    input_file  = open(dir_path + "/input/region_graph.txt", "r")
    google_map  = gmplot.GoogleMapPlotter( (limit_top + limit_bottom) / 2.0, (limit_left + limit_right) / 2.0, 15, 'AIzaSyCPYUnvfoim1Kt8PlHwN2X3h_hTxShz0mM')

    for line in input_file: 
        nodes = line.replace('\n', '').split(" ")
        if len(nodes) == 4:
            latitudes   = [float(nodes[0]), float(nodes[2])]
            longitudes  = [float(nodes[1]), float(nodes[3])]
            google_map.plot(latitudes,longitudes,'cornflowerblue', edge_width=5)

    google_map.draw(dir_path + "/output/region_path.html")

else:
    print("Invalid option. You need to provide one option: [fetch|path]")

# docker run --name mapper_fetch -i -v $(pwd):/usr/src/app cs2100 fetch
# docker run --name mapper_path -i -v $(pwd):/usr/src/app cs2100 path
