#ifndef GRAPH_BFS_H
#define GRAPH_BFS_H

#include "Graph.h"
using namespace std;

template <class GraphTrait>
class Bfs{
public:
    typedef ::Node< Graph<GraphTrait> > Node;
    typedef ::Edge< Graph<GraphTrait> > Edge;
    typedef typename GraphTrait::NodeContent NodeContent;
    typedef typename ::Graph<GraphTrait> graph;
    typedef std::list<Edge*>    EdgesList;
    typedef vector<NodeContent>visited;
    typedef list<NodeContent>queue;
    typedef typename EdgesList::iterator    EdgesIterator;

    visited get_visited(){ return this->v;}
    queue get_queue(){return this->q;}

    void BFS(){
        bfs();
    }

    Bfs(NodeContent node, graph g){
        this->g=g;
        this->nodeStart=node;
        this->q=new queue();
        this->v=new visited();
    }

private:
    visited *v;
    queue *q;
    graph g;
    EdgesIterator edges_iterator;
    NodeContent nodeStart;

    void bfs(){
        q->push_back(nodeStart);
        v->push_back(nodeStart);
        NodeContent aux;
        if(g.find_node_bfs(nodeStart)!=-1)
        {
            while(!q->empty()){
                aux=(*q->begin());
                q->pop_front();
                cout<<" "<<aux;
                auto list_aux = g.get_vector().at(g.find_node_bfs(aux))->get_list();

                for(edges_iterator=list_aux.begin(); edges_iterator!=list_aux.end(); ++edges_iterator){
                    for(size_t i=0; i<v->size(); i++){
                        if ((*edges_iterator)->get_vertice(1).get_content() == v->at(i)) goto node_visited;
                    }
                    aux=(*edges_iterator)->get_vertice(1).get_content();
                    q->push_back(aux);
                    v->push_back(aux);
                    node_visited: continue;
                }
            }
        }
        delete v;
        delete q;
    }

};

#endif