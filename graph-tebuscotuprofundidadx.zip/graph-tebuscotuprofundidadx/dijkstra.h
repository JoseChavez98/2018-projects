#ifndef _Dijkstra_
#define _Dijkstra_
#include <iostream>
#include <string>
#include <utility>
#include <map>
#include <iomanip>
#include "Graph.h"
#include <limits>
using namespace std;
template <class GraphTrait>
class Dijsktra
{
public:
    typedef ::Node< Graph<GraphTrait> > Node;
    typedef ::Edge< Graph<GraphTrait> > Edge;
    typedef typename GraphTrait::NodeContent NodeContent;
    typedef typename ::Graph<GraphTrait> graph;
    typedef typename GraphTrait::EdgeContent EdgeContent;
    typedef std::list<Edge*>    EdgesList;
    typedef vector<NodeContent>visited;
    typedef typename EdgesList::iterator    EdgesIterator;
    typedef pair<NodeContent, EdgeContent> Node_W;
    typedef  map<NodeContent, EdgeContent> vec_Node_W;
    typedef typename vec_Node_W::iterator  map_iterator;
    Dijsktra(graph g, NodeContent node) :node(node), g(g) {
        Generate_Map();
        Generate_Visited();
    }

    void dijsktra() {
        algorithm_dijkstra();
        Print_tags();
    }
private:
    NodeContent node;
    graph g;
    vec_Node_W map_node;
    visited *v;
    void Print_tags() {
        for (map_iterator it = map_node.begin(); it != map_node.end(); ++it)
        {
            cout << "\nthe minimum cost from node " << this->node << " to node " << it->first << " is " << it->second;
        }
    }
    void Generate_Visited() {
        this->v = new visited();
        auto size = this->g.get_vector().size();
        auto vec_node = this->g.get_vector();
        for (size_t i = 0; i < size; i++)
        {
            this->v->push_back(vec_node.at(i)->get_content());
        }

    }
    void Generate_Map() {
        auto size = this->g.get_vector().size();
        auto vec_node = this->g.get_vector();
        for (size_t i = 0; i < size; i++)
        {

            map_node.insert(Node_W(vec_node.at(i)->get_content(), numeric_limits<EdgeContent>::max()));
        }
    }
    void algorithm_dijkstra() {
        map_iterator p = map_node.find(this->node);
        v->push_back(this->node);
        if (p!=map_node.end())
        {
            p->second = 0;
            while (!v->empty())
            {

                auto u_index = Find_min_Visited();

                auto u = v->at(u_index);
                v->erase(v->begin() + u_index);
                auto list_aux = g.get_vector().at(g.find_node_bfs(u))->get_list();

                for (EdgesIterator it = list_aux.begin(); it != list_aux.end(); ++it)
                {
                    auto next_node_u = (*it)->get_vertice(1).get_content();

                    if (Find_visited(next_node_u)) {

                        auto cost_next = map_node.find(next_node_u);
                        if (cost_next->second>map_node.find(u)->second+(*it)->get_edge_content())
                        {
                            cost_next->second = map_node.find(u)->second + (*it)->get_edge_content();
                        }
                    }
                }


            }

        }
        else
        {
            cout << "the node doesn't exist";
        }


    }
    auto Find_min_Visited() {
        auto min = 0;
        for (size_t i = 0; i < this->v->size(); i++)
        {
            if (map_node.find(v->at(min))->second > map_node.find(v->at(i))->second) min = i;
        }
        return min;
    }
    bool Find_visited(NodeContent node) {;
        for (size_t i = 0; i < v->size(); i++)
        {
            if (v->at(i) == node) return true;
        }
        return false;
    }

};




#endif // _Dijkstra_