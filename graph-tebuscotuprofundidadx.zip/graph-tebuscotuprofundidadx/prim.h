//
// Created by jose on 10/11/18.
//

#ifndef GRAPH_PRIM_H
#define GRAPH_PRIM_H
#include "Graph.h"
#include <algorithm>
#include <vector>
#include <queue>


using namespace std;
template <class GraphTrait>
class Prim{
    typedef ::Node< Graph<GraphTrait> > Node;
    typedef ::Edge< Graph<GraphTrait> > Edge;

    
    public:
    struct comparator {
        bool operator () (const Edge a, const Edge b) {
            return a.get_edge_content() > b.get_edge_content();
        }
    };

    priority_queue <Edge, vector<Edge>, comparator > p;

    vector<Node> visited_nodes;
    vector<Edge> path_edges;
    
    
    Graph<GraphTrait> graph;


    explicit Prim(Graph<GraphTrait> g){
        this->graph=g;

    }

    bool find_visited(Edge *e){
        for(auto &i : this->visited_nodes){
            if(e->get_vertices(1)->get_content()==i.get_content()){
                return true;
            }
        }return false;
    }
    bool find_cicle(Edge e){
        for(auto &i : visited_nodes){
            if(e.get_vertice(1)==i){
                return true;
            }
        }return false;
    }
    void insert_visit_node(Node node){
        visited_nodes.push_back(node);
        for(auto &i : node.get_list()){
            if(!find_visited(i)){
                p.push(*i);
            }
        }
    }

    void make(){
    insert_visit_node(* (graph.get_vector()[0]) );
    path_edges.push_back(p.top());
    p.pop();
    while(!p.empty()){
        insert_visit_node(path_edges[path_edges.size()-1].get_vertice(1));
        if(!find_cicle(p.top())){
            path_edges.push_back(p.top());
            p.pop();
        }else{
            p.pop();
        }
    }
    } 
  
    
    void print(){
        cout<<endl;
            cout<<"MST (PRIM): ";
        for(auto &i : path_edges){
            cout<<" {"<<i.get_vertice(0).get_content()<< ","<<i.get_vertice(1).get_content()<<"} -";
        }
    }

};
#endif //GRAPH_PRIM_H
