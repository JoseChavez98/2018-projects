//
// Created by jose on 9/30/18.
//

#ifndef GRAPH_EDGE_H
#define GRAPH_EDGE_H

template <class GraphTrait>
class Edge {
private:
    typedef typename GraphTrait::EdgeContent EdgeContent;
    typedef typename GraphTrait::Node Node;

    bool is_directed{};
    EdgeContent edge_content;
    Node * vertices[2];

public:
    Edge () = default;
    Edge (bool is_directed, EdgeContent edge_content, Node  *vertices[2]){
        this->is_directed=is_directed;
        this->edge_content=edge_content;
        for( int i=0;i<2;i++){
            this->vertices[i]=vertices[i];
        };
    }
  /*  ~ Edge(){
        delete [] vertices[];

    };*/
  bool get_choice(){
      return this->is_directed;
  }
    EdgeContent get_edge_content()const{
        return this->edge_content;
    }

    Node *get_vertices(int i){
        return this->vertices[i];
    }
    Node get_vertice(int i)const{
        return *(this->vertices[i]);
    }
    void swap(){
    Node *newnode= vertices[0];
        vertices[0]=vertices[1];
        vertices[1]=newnode;
    }
     bool operator <(const Edge &e1){
         return ( (edge_content<e1.get_edge_content())? true : false );
     }
     bool operator >(const Edge &e1){
         return ( (edge_content>e1.get_edge_content())? true : false );
     }
     bool operator ==(const Edge &e1){
         return ( (edge_content==e1.get_edge_content())? true : false );
     }
};


#endif //GRAPH_EDGE_H
