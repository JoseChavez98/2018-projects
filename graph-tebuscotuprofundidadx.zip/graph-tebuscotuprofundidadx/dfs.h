#ifndef GRAPH_DFS_H
#define GRAPH_DFS_H

#include "Graph.h"
using namespace std;

template <class GraphTrait>
class Dfs {
public:
    typedef ::Edge< Graph<GraphTrait> > Edge;
    typedef typename GraphTrait::NodeContent NodeContent;
    typedef typename ::Graph<GraphTrait> graph;
    typedef std::list<Edge*>    EdgesList;
    typedef vector<NodeContent>visited;
    typedef typename EdgesList::iterator    EdgesIterator;

    void DFS() {

        dfs(nodeStart);
        delete v;
    }

    Dfs(NodeContent node, graph g) {
        this->g = g;
        this->nodeStart = node;
        this->v = new visited();


    }

private:
    visited *v;
    graph g;
    NodeContent nodeStart;

    void dfs(NodeContent node) {

        auto index = g.find_node_bfs(node);
        if (index >= 0)
        {
            v->push_back(node);
            auto list_aux = g.get_vector().at(index)->get_list();

            for (EdgesIterator edges_iterator = list_aux.begin(); edges_iterator != list_aux.end(); ++edges_iterator) {
                for (size_t i = 0; i < v->size(); i++) {
                    if ((*edges_iterator)->get_vertices(1)->get_content() == v->at(i)) goto node_visited;
                }
                dfs((*edges_iterator)->get_vertices(1)->get_content());

                node_visited: continue;
            }
            cout <<" "<< node;


        }
    }

};

#endif