//
// Created by jose on 10/14/18.
//
#ifndef GRAPH_DISJOINTSET_H
#define GRAPH_DISJOINTSET_H
#include <iostream>
#include <map>
#include "Graph.h"
using namespace std;

template <class GraphTrait>


class DisjointSet {
    typedef typename GraphTrait::NodeContent    NodeContent;

    public:
    unsigned long int size{};
    map<NodeContent ,unsigned long int > rank;
    map<NodeContent,NodeContent > set;

    explicit DisjointSet(Graph<GraphTrait> graph) {
            this->size=graph.get_vector().size();
            for(auto &i: graph.get_vector()){
                rank[i->get_content()]=1;
                set[i->get_content()]=i->get_content();
            }
        };
        ~DisjointSet() {};

    void print_set(){
        auto iter=set.begin();
        for(;iter!=set.end();iter++){
            
        std::cout<<iter->first<<"-"<<iter->second<<" , ";
        }
    }

        bool check(){
            auto it = rank.begin();
            for(;it!=rank.end();it++){
                if(it->second==size-2)return true;
            }return false;
        }
        
        void unionSet(NodeContent a, NodeContent b){
            if(rank[a]<rank[b]){
                //cout<<"\nAAAAAA\n";
                NodeContent r;
                r=set[a];
                for(auto i=set.begin();i!=set.end();i++){
                    if(i->second==r){
                        rank[b]+=1;
                        set[i->first]=set[b];

                    }
                }
                //std::cout<<"padre : "<<set[b]<<'\n';
                //print_set();
            }
            else if(rank[a]>rank[b]){
                //cout<<"\nBBBBB\n";
                NodeContent x;
                x=set[b];
                    for(auto i=set.begin();i!=set.end();i++){
                        
                        //cout<<x<<": ";
                        if(i->second==x){
                            //cout<<i->second<<"->";
                            rank[a]+=1;
                            set[i->first]=set[a];
                            //cout<<set[i->first]<<'\n';

                        }

            }
                //std::cout<<"padre : "<<set[a]<<'\n';
                //print_set();
        }else{
            //cout<<"\nCCCCCCC\n";
            NodeContent h;
            h=set[b];
                for(auto i=set.begin();i!=set.end();i++){
                    
                    if(i->second==h){
                        //cout<<" || "<<"cambio: " <<i->second<<" newp-> ";
                        rank[a]+=1;
                        set[i->first]=set[a];
                        //cout<<set[i->first]<<'\n';

                    }
            }//std::cout<<"padre : "<<set[a]<<'\n';
                //print_set();
        }}
        
        NodeContent find(NodeContent a){
            return set[a];
        }
        
};


#endif //GRAPH_DISJOINTSET_H