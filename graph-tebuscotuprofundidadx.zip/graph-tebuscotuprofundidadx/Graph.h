
//
// Created by jose on 9/30/18.
//

#ifndef GRAPH_GRAPH_H
#define GRAPH_GRAPH_H
#include <iostream>
#include <vector>
#include <list>
#include "Node.h"
#include "Edge.h"


template <class Trait>
class Graph {
public:
    typedef ::Node< Graph<Trait> > Node;
    typedef ::Edge< Graph<Trait> > Edge;

    typedef std::vector<Node*>  NodesVector;
    typedef std::list<Edge*>    EdgesList;

    typedef typename Trait::NodeContent     NodeContent;
    typedef typename Trait::EdgeContent     EdgeContent;
    typedef typename NodesVector::iterator  NodesIterator;
    typedef typename EdgesList::iterator    EdgesIterator;

private:
    NodesVector nodes_vector;

    NodesIterator nodes_iterator;
    EdgesIterator edges_iterator;



public:
    Node *ptr;
    Edge *ptr2;
    bool choice=false;

    Graph() = default;
    auto get_vector(){
        return this->nodes_vector;
    }

    bool insert_node(NodeContent node_content) {
        if(!nodes_vector.empty()) {
            for (nodes_iterator=nodes_vector.begin(); nodes_iterator != nodes_vector.end(); ++nodes_iterator) {
                if ((*nodes_iterator)->get_content() == node_content) {
                    return false;
                }
            }
            auto *newnode = new Node(node_content);
            nodes_vector.push_back(newnode);
            return true;
        }
        else{
            auto *newnode = new Node(node_content);
            nodes_vector.push_back(newnode);
            return true;
        }


    }

    void delete_all_conexions(Node * node){
        EdgesList list=node->get_list();
        auto it=list.begin();
        for(it;it!=list.end();++it){
            for(auto iterator= (*it)->get_vertices(1)->get_list().begin();iterator!=(*it)->get_vertices(1)->get_list().end();iterator++){

               if((*iterator)->get_vertices(1)->get_content()==node->get_content()){
                   // std::cout<<(*iterator)->get_vertices(0)->get_c Node * vertices[2];ontent()<<" ";
                   //std::cout<<(*iterator)->get_edge_content()<<" - ["<<(*iterator)->get_vertices(0)->get_content()<<" , "<<(*iterator)->get_vertices(1)->get_content()<<" ] ";
                   if((*iterator)->get_vertices(0)->delete_edge(*iterator)){
                        break;
                   }
                   
               }
            }
            for(auto &i: list){
                node->delete_edge(i);
            }
        }

    }
    void delete_all_directed_conexions(Node * node){
        for(auto &i: nodes_vector){
            for(auto &j:i->get_list()){
                if(j->get_vertices(1)->get_content()==node->get_content()){
                    i->delete_edge(j);
                    break;
                }
            }
        }

    }

    bool delete_node(NodeContent node_content) {
        if(!choice){
        if(find_node(node_content)) {
            delete_all_conexions(ptr);
            for(auto &i : nodes_vector){
                if(i->get_content()==ptr->get_content()){
                    for(nodes_iterator=nodes_vector.begin();nodes_iterator!=nodes_vector.end();++nodes_iterator){
                        if((*nodes_iterator)->get_content() == ptr->get_content()){
                            nodes_vector.erase(nodes_iterator);
                            return true;
                        }
                    }
                }
            }
        }return false;}
        else{
            if(find_node(node_content)) {
                delete_all_directed_conexions(ptr);
               /* for(auto &i: ptr->get_list()){
                    ptr->delete_edge(i);
                    break;
                }*/
                for(auto &i : nodes_vector){
                    if(i->get_content()==ptr->get_content()){
                        for(nodes_iterator=nodes_vector.begin();nodes_iterator!=nodes_vector.end();++nodes_iterator){
                            if((*nodes_iterator)->get_content() == ptr->get_content()){
                                nodes_vector.erase(nodes_iterator);
                                return true;
            }

        }

    }}}return false;}}

    void insert_edge(EdgeContent edge_content, NodeContent start, NodeContent end, bool is_directed) {
        choice=is_directed;
        Node *vertices[2];
        this->find_node(start);
        vertices[0]=ptr;
        this->find_node(end);
        vertices[1]=ptr;
        Node *vertices2[2];
        vertices2[0]=vertices[1];
        vertices2[1]=vertices[0];
        if(!is_directed){
            auto *newedge = new Edge{is_directed,edge_content,vertices};
            auto *newedge2 = new Edge{is_directed,edge_content,vertices2};

            newedge->get_vertices(0)->set_list(newedge);

            newedge->get_vertices(1)->set_list(newedge2);

        }


        else{
            auto *newedge = new Edge{is_directed,edge_content,vertices};

                vertices[0]->set_list(newedge);
        }
    }


   bool find_node(NodeContent node_content){

       for (nodes_iterator=nodes_vector.begin(); nodes_iterator != nodes_vector.end(); ++nodes_iterator) {
           if ((*nodes_iterator)->get_content() == node_content) {
               ptr= *nodes_iterator;
               return true;
           }
       }
       std::cout<<"nodo invalido\n";
       return false;
   }

    int find_node_bfs(NodeContent nodo) {
        for (size_t i = 0; i < nodes_vector.size(); i++)
        {
            if (nodes_vector.at(i)->get_content() == nodo) { return i; }
        }
        return -1;
    }

    bool find_edge( NodeContent start, NodeContent end, EdgesList l){
        for (edges_iterator=l.begin(); edges_iterator != l.end(); ++edges_iterator) {

            if ( (*edges_iterator)->get_vertices(0)->get_content()==start and (*edges_iterator)->get_vertices(1)->get_content()==end) {
                ptr2=*edges_iterator;
                return true;
            }
        }
        return false;
    }


    bool delete_edge(NodeContent start, NodeContent end) {
        if (!choice) {
            if (find_node(start)) {
                if (find_edge(start, end, ptr->get_list())) {
                    ptr->delete_edge(ptr2);

                }
            } else {
                return false;
            }
            if (find_node(end)) {
                if (find_edge(end, start, ptr->get_list())) {
                    ptr->delete_edge(ptr2);
                }
            } else {
                return false;
            }
            return true;

        } else {
            if (find_node(start)) {
                if (find_edge(start, end, ptr->get_list())) {
                    ptr->delete_edge(ptr2);

                }
            } else {
                return false;
            }
        }

    }
    void print_struct(){
        for(auto &i : nodes_vector){
            i->print_list();
        }

    }


};

#endif //GRAPH_GRAPH_H
