//
// Created by jose on 10/14/18.
//
#ifndef GRAPH_KRUSKAL_H
#define GRAPH_KRUSKAL_H

#include <queue>
#include <iostream>
#include "Graph.h"
#include "Disjointset.h"
#include <vector>

using namespace std;

template <class GraphTrait>
class Kruskal{
public:

    typedef ::Edge< Graph<GraphTrait> > Edge;
    typedef ::Node< Graph<GraphTrait> > Node;
    typedef typename GraphTrait::NodeContent    NodeContent;
    struct comparator {
        bool operator () (const Edge a, const Edge b) {
            return a.get_edge_content() > b.get_edge_content();
        }
    };


    priority_queue <Edge, vector<Edge>, comparator > p;
    
    vector <Edge> vec;
    vector<Node> visited_nodes;
    vector<Edge> path_edges;
    DisjointSet<GraphTrait> dj = DisjointSet<GraphTrait>(Graph<GraphTrait>());
    bool in(Edge e){
        for(auto &i : vec){
            if(e.get_vertice(0)==i.get_vertice(1) && e.get_vertice(1)==i.get_vertice(0) ){
                return true;
            }
        }return false;graph.insert_node('A');
}    

    explicit Kruskal( Graph<GraphTrait> g){

     DisjointSet djex = DisjointSet{g};
     this->dj=djex; 
        auto n=g.get_vector()[0];
        for(auto &x : n->get_list()){
            vec.push_back( *x );
            //std::cout<<x->get_edge_content();
            break;
        }


        for(auto &i : g.get_vector()){
            for(auto &j : i->get_list()){
                if(!in(*j)){

                    vec.push_back(*j);
                }
        }
    }
    for(auto &i : vec){
        p.push(i);
    }

    }

    void make(){
       /*visited_nodes.push_back(p.top().get_vertice(0));
        visited_nodes.push_back(p.top().get_vertice(1));
        //std::cout<<p.top().get_edge_content()<<", ";
        path_edges.push_back(p.top());
        p.pop();
        dj.unionSet(p.top().get_vertice(0).get_content(),p.top().get_vertice(1).get_content());
*/


        while(!p.empty()){
            auto a =dj.find(p.top().get_vertice(0).get_content());
            //std::cout<<p.top().get_vertice(0).get_content()<<" padre-> "<<a<< " || ";
            auto b =dj.find(p.top().get_vertice(1).get_content());
            //std::cout<<p.top().get_vertice(1).get_content()<<" padre-> "<<b<< "  ";
            if(a != b ){
                visited_nodes.push_back(p.top().get_vertice(0));
                visited_nodes.push_back(p.top().get_vertice(1));
                dj.unionSet(p.top().get_vertice(0).get_content(),p.top().get_vertice(1).get_content());
                //std::cout<<"add: "<<p.top().get_vertice(0).get_content()<<p.top().get_vertice(1).get_content()<<'\n';
                path_edges.push_back(p.top());
                p.pop();
            }else{
                //std::cout<<"pop: "<<p.top().get_vertice(0).get_content()<<p.top().get_vertice(1).get_content()<<'\n';
                p.pop();
            }
        }
        
    }

    void print(){
         cout<<endl;
            cout<<"MST (KRUSKAL): ";
        for(auto &i : path_edges){
            cout<<" {"<<i.get_vertice(0).get_content()<< ","<<i.get_vertice(1).get_content()<<"} -";
        }
    
   }
    void print_queue(){
        while(!p.empty()){
            std::cout<<p.top().get_edge_content()<<" - ";
            p.pop();

        }
for(auto &i : vec){
    std::cout<<i.get_edge_content()<<" ";
}


    }
};

#endif //GRAPH_KRUSKAL_H