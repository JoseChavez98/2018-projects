//
// Created by jose on 9/30/18.
//

#ifndef GRAPH_NODE_H
#define GRAPH_NODE_H

#include "Edge.h"
#include "Graph.h"



template <class GraphTrait>
class Node {
private:

    typedef typename GraphTrait::NodeContent    NodeContent;
    typedef typename GraphTrait::EdgeContent    EdgeContent;
    typedef typename GraphTrait::Edge           Edge;
    typedef typename GraphTrait::EdgesList      EdgesList;

    typedef typename EdgesList::iterator    EdgesIterator;



    EdgesList edges_list;
    NodeContent node_content;
    

public:

    Node () = default;
    Node (NodeContent node_content){
        this->node_content= node_content;
    }


    NodeContent get_content()const {
        return this->node_content;
    }
    EdgesList & get_list(){
        return this->edges_list;
    }
    void set_list(Edge *e){
        this->edges_list.push_back(e);
    }

    bool delete_edge(Edge *e){

        for(EdgesIterator it=edges_list.begin();it!=edges_list.end();++it){
            if(((*it)->get_vertices(0))->get_content() == (e->get_vertices(0))->get_content() and ((*it)->get_vertices(1))->get_content() == (e->get_vertices(1))->get_content()){
                this->edges_list.remove(*it);
                return true;
       }
   }return false;
    }

    void print_list(){
        std::cout<<this->node_content<<" -> ";
        for(auto &i:edges_list){
            std::cout<<i->get_edge_content()<<" - ";
        }
        std::cout<<'\n';
    }
    Edge get_first(){
        return (edges_list[0]);
    }
     
     bool operator <(const Node &e1){
         return ( (node_content<e1.get_content())? true : false );
     }
     bool operator >(const Node &e1){
         return ( (node_content>e1.get_content())? true : false );
     }
     bool operator ==(const Node &e1){
         return ( (node_content == e1.get_content())? true : false );
     }
      bool operator !=(const Node &e1){
         return ( (node_content != e1.get_content())? true : false );
     }
};
#endif //GRAPH_NODE_H
