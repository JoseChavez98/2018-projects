    #include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include "Graph.h"
#include "bfs.h"
#include "dfs.h"
#include "prim.h"
#include "dijkstra.h"
#include "kruskal.h"



class CustomTrait {
public:
    typedef int NodeContent;
    typedef std::string EdgeContent;
};

class CustomTrait2 {
public:
    typedef char NodeContent;
    typedef int EdgeContent;
};
class CustomTrait3 {
public:
    typedef std::string NodeContent;
    typedef double EdgeContent;
};
//void read( Graph<CustomTrait3> graph,std::map<string,string> id);
int main() {
    
    Graph<CustomTrait2> graph;
    //std::map<string,string> id;
    //read(graph,id);

    //graph.insert_node('A');
    //graph.insert_node('B');
    //graph.insert_node('C');
    //graph.insert_node('D');
    //graph.insert_node('E');
    //graph.insert_node('F');
    //graph.insert_node('G');
    //graph.insert_node('H');
    //graph.insert_node('I');

    graph.insert_node('A');
    graph.insert_node('B');
    graph.insert_node('C');
    graph.insert_node('D');
    graph.insert_node('E');

    graph.insert_edge(5,'A','B',false);
    graph.insert_edge(2,'A','C',false);
    graph.insert_edge(3,'D','C',false);
    graph.insert_edge(6,'D','E',false);
    /*graph.insert_edge(3,'C','E',false);
    graph.insert_edge(1,'C','F',false);
    graph.insert_edge(3,'E','F',false);
    graph.insert_edge(8,'D','G',false);
    graph.insert_edge(5,'D','H',false);
    graph.insert_edge(6,'F','H',false);
    graph.insert_edge(9,'G','H',false);
    graph.insert_edge(2,'G','I',false);
    graph.insert_edge(11,'H','I',false);
*/

    //if(graph.delete_edge(4,6));
    //if(graph.delete_edge(2,4));
    //if(graph.delete_node(6));
    //if(graph.delete_node(4));
    graph.print_struct();

    std::cout<<'\n';

    Bfs< CustomTrait2> newbfs('A',graph);
    newbfs.BFS();

    cout << "\n";

    Dfs < CustomTrait2>newdfs('A', graph);
    newdfs.DFS();


    std::cout << '\n';

    Prim newprim =Prim{graph};
    newprim.make();
    newprim.print();

    std::cout << '\n';

    Kruskal newk =Kruskal(graph);
    newk.make();
    newk.print();

    std::cout<<'\n';

    Dijsktra < CustomTrait2> newdijkstra(graph, 'A');
    newdijkstra.dijsktra();
    
    std::cout<<'\n';

    
    return (0);
};

/*
void read( Graph<CustomTrait3> graph,std::map<string,string> id){
    
    std::fstream file("/home/jose/CLionProjects/graph-tebuscotuprofundidadx/mapper/output/region_graph.txt",std::ios::in);
    std::string dato;
    
    bool on =true;
    double cont=0;
    double size;
    std::string arr1[2];
    std::string arr[3];
    int f=0;
    
    while(getline(file,dato)){
        cout<<dato<<'\n';
        if(on){
            double size = stod(dato);
            on=false;
        }

        if(cont<size){
 std::string s = dato;
            std::string delimiter = " ";

            size_t pos = 0;
            std::string token;
            while ((pos = s.find(delimiter)) != std::string::npos) {
                token = s.substr(0, pos);
                arr1[0]=token;
                cout<<token<<" , ";
                s.erase(0, pos + delimiter.length());
                break;
            }
            arr1[1]=s;
            cout<<s<<'\n';
            id[arr1[0]]=arr1[1];
            
            
           
            graph.insert_node(arr1[0]);
            cont++;

        
        }else{
            std::string s = dato;
            std::string delimiter = " ";

            size_t pos = 0;
            std::string token;
            while ((pos = s.find(delimiter)) != std::string::npos) {
                token = s.substr(0, pos);
                arr[f]=token;
                f++;
                s.erase(0, pos + delimiter.length());
            }
            arr[f]=s;
            f=0;
            
            
            graph.insert_edge(stod(arr[2]),arr[0],arr[1],true);

        }
    }

}
*/