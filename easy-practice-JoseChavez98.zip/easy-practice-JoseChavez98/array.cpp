#include <iostream>
#include <memory>


template <class AnyObject>
class ArrayPointer {
private:
    unsigned int count;
    std::shared_ptr<AnyObject> content;

public:
    ArrayPointer() = default;
    
    ArrayPointer(unsigned int size){
    
        this->content = std::shared_ptr<AnyObject>(new AnyObject[size], [](AnyObject * ptr){
               delete[] ptr;
           });
           this->count=size;
    }
    
    ArrayPointer(unsigned int size, AnyObject defaultValue) : ArrayPointer(size){
        
        for(unsigned int i=0;i<size;i++){
            *(this->content.get()+i)=defaultValue;
        }
       
    }
    
    ArrayPointer(ArrayPointer<AnyObject> a, ArrayPointer<AnyObject> b) : ArrayPointer(a.count + b.count){
        auto difference=a.count;
        for(unsigned int i=0;i<a.count;i++){
            *(this->content.get()+i)=*(a.get_content().get()+i);
            *(this->content.get()+(i+difference))=*(b.get_content().get()+i);
        }
    }

    inline AnyObject& operator[] (unsigned int index) const{
        return *(content.get() + index);
    }

    inline std::pair<AnyObject, AnyObject> min_max() const {
        AnyObject minimum = std::numeric_limits<AnyObject>::max();
        AnyObject maximum = std::numeric_limits<AnyObject>::min();

        /* Return the min and max element using threads */

        return {minimum, maximum};
    }
    
    inline unsigned int size () {
        return 0; /* Returns the number of elements */
    }
    
    std::shared_ptr<AnyObject> get_content(){
        return this->content;
    }

    inline void print(){
        printf("Array with %u elements: ", count);
        for( unsigned int i = 0 ; i < count ; ++i){ 
            std::cout << this->operator[](i) << " "; 
        }
        printf("\n");
    }
};


int main() {
    ArrayPointer<int> obj (5,1);
    ArrayPointer<int> obj1 (4,2);
    ArrayPointer<int> objtest (obj,obj1);
    objtest.print();

    return 0;
}