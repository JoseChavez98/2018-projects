#include <iostream>
#include <vector>
#include <algorithm>
#include <numeric>
#include <cmath>

std::vector<unsigned int> find_primes(unsigned int k) {
    std::vector<unsigned int> primes(k);
    std::iota(primes.begin(), primes.end(), 2);

    for(auto i=2;i<sqrt(k);++i){
        if(i!=0) 
        for(auto j=i ; j<(k/i);j++){
            primes[i*j]=0;
        }
    }

    return primes;
}

int main() {

    unsigned int k = 10;

    auto prime_numbers = find_primes(k-1);
    for (auto prime : prime_numbers) {
        std::cout << prime << " ";
    }

    std::cout << "\n";
    return 0;
}