# Programming Practice

Answer the following questions:

1. How many times will this loop execute? Explain your answer.
```c++
unsigned char bound = 150;
for (unsigned char i = 0; i < 2 * bound; ++i);
150
este for hara un loop infinito porque ocurrira un overflow debido al limite de char.

2. How the ++ operator works in this example?

```c++
int i = 5;
int j = i++;
``` El operador aumenta de a uno al entero que contiene la variable i, i se convierte en 6;

3. Here you have 2 procedures which one has better performance and why ?

```c++
for (auto iterator = v.begin(); iterator != v.end(); iterator++) {
	iterator->print();
}
````

```c++
for (auto iterator = v.begin(); iterator != v.end(); ++iterator) {
	iterator->print();
}
```
El mas optimo es el segundo ya que realiza la instruccion de ++ primero, entonces la primera tendra que mover mas registros para llegar a la forma generica del ++iterator.

4. Describe the behaviour of the following code and explain why is it working like that. What happens if I change the type? 

```C++
template <class T>
void fun(T value) {
    static int count = 0;
    std::cout << value << " " << count << "\n";
    ++count;
}
La función fun recive un valor de tipo T , esta función imprimira el valor dado junto con un con count en el valor que se encuentre , ya que este es una variable estatica (solo una copia), por eso ira aumentando de a uno cada vez que lo llames.
int main(){
    fun<std::string>("cs");
    fun<std::string>("21");
    fun<std::string>("00");
  
    return 0;
}

```el programa imprime:
cs 0
21 1
00 2

end.


5. What is the difference between `unique_ptr<>`, `shared_ptr<>` and `weak_ptr<>`. Describe and code your response with different examples.

el unique_ptr se encarga de administrar un puntero, este unique manejara ese puntero y nadie mas lo contendra, cuando se haga delete de este se encargara de borrar el puntero contenido.
el shared pointer comparte un puntero entre varios shared pointer, pero para hacer el delete, solo se podra cuando el ultimo shared pointer que apunte al pointer guardado elimine la estructura.
el weak pointer almacena de manera ( no posesiva) un pointer denyro de un shared pointer, normalmente se usa para hacer un trackeo de ese puntero, este puede ser borrado de manera sencilla(no borra el shared pointer).


6. Consider the following code:

```c++
template <int N>
struct factorial {
	static const int value = factorial<N - 1>::value * N;
};

template <>
struct factorial<0> {
	static const int value = 1;
};

int main(){
    factorial<3> f;
    std::cout << f.value << "\n";
  
    return 0;
}
```

How the factorial of a number is calculated ?

factorial tiene un sentido recursivo por medio de los templates, primero llama a la fuciom factorial<N> que hara la recursion general, para llamar a varios factoriales con un diferente N (N-1) que le ingresas. El segundo struct sirve como el caso base de la recursion, cuando se llame a factorial<0> se ingresara a este struct y se detiene la recursion.

7. About templates what is the Curiously Recurring Template Pattern (CRTP)? Describe and write/code an example.
es un idimoa de C++ , trata de la herencia de una template class, tendra una clase derivada que se usara a si misma como template parameter de la clase base.

template<typename T>
class Base{
    ...
};
class Derived : public Base<Derived>{
...
};


//##########################################################################
recien me entero que queria que respondamos en ingles, dijo que me pasaria las anteriores preguntas. GRACIAS
//#########################################################################


8. What are the benefits and drawbacks of template metaprogramming?

A benefit  is that Template meta-programming allows extremely flexible interfaces that are type safe and high performance.
and the cons are that , template meta-programming is really hard to understand, it will be hard for someone who is not an expert of it.
another thing is that  Template meta-programming often leads to extremely poor compiler time error messages.
to finish , another con is that Template meta-programming makes the refactoring really hard.

9. Implement the following exercises:

- ***array.cpp***: Write your own array data structure to store a set of elements. You can only use pointers arithmetic to move along the array. After that answer why is it a `shared_ptr<>`? or you consider it should be changed?

- ***primes.cpp***: Write an efficient algorithm to get all the prime numbers between 1 and `k`, where `k`is a parameter of your function.

- ***heapsort.cpp***: Write a heapsort algorithm to sort some elements of any type

