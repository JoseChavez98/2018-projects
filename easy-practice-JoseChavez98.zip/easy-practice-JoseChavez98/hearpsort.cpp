#include <iostream>
#include <vector>
#include <algorithm>
#include <random>

int main() {
    std::random_device device;
    std::mt19937 generator(device());
    std::uniform_int_distribution distribution(1, 500);

    std::vector<int> unsorted_array(10);

    std::generate(unsorted_array.begin(), unsorted_array.end(), [&]() {
		return distribution(generator);
	});

    std::make_heap(unsorted_array.begin(),unsorted_array.end());
    std::sort_heap(unsorted_array.begin(),unsorted_array.end());

    std::for_each(unsorted_array.begin(), unsorted_array.end(), [](auto element){
        std::cout << element << " ";
    });


    std::cout << "\n";
    return 0;
}