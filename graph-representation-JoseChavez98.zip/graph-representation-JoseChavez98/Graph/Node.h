//
// Created by jose on 9/20/18.
//

#ifndef GRAPH_NODE_H
#define GRAPH_NODE_H

#endif //GRAPH_NODE_H
template < class T >
struct Node{
    T val;
    Node *next_pointer;


};