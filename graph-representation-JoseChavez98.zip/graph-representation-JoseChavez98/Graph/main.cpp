#include <iostream>
#include "matrix.h"


int main() {

    list<int> lista;
    lista.insert(1);lista.insert(2);lista.insert(4);
    list<int> lista1;
    lista1.insert(2);lista1.insert(1);lista1.insert(3);
    list<int> lista2;
    lista2.insert(3);lista2.insert(2);lista2.insert(1);
    list<int> lista3;
    lista3.insert(4);lista3.insert(1);lista3.insert(4);
    list<int> lista4;
    lista4.insert(5);lista4.insert(3);lista4.insert(1);

std::vector<list<int>>list_ad;
    list_ad.push_back(lista);
    list_ad.push_back(lista1);
    list_ad.push_back(lista2);
    list_ad.push_back(lista3);
    list_ad.push_back(lista4);

    matrix<int> a(list_ad);
    a.show();


    return 0;
}