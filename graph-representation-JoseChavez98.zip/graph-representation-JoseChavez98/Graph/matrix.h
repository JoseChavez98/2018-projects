//
// Created by jose on 9/20/18.
//

#ifndef GRAPH_GRAPH_H
#define GRAPH_GRAPH_H
#include <iostream>
#include <cstring>
#include "vector"
#include "list.h"
#endif //GRAPH_GRAPH_H



template <class T>
class matrix{

public:
    unsigned long cantidad;

    int **mat;
    explicit matrix(std::vector<list<T>>&vec){
        this->cantidad= vec.size()+1;

        mat = new int *[cantidad];


        for(int i=0;i<cantidad;i++){
            mat[i]= new int [cantidad];
        }
        for(int i=0;i<cantidad;i++){

            for(int j=0;j<cantidad;j++){
                if(i==0)mat[i][j]=j;
                else if(j==0){
                    mat[i][j]=i;
                }
                else{
                    mat[i][j]=0;
                }
            }
        }



        for( auto i=0;i<vec.size();++i ){
            auto h=vec[i].size();
            int  *l=vec[i].conexion(h-1);

                for(int j=0;j<h-1;j++){

                   mat[i+1][l[j]]=1;
            }
        }
    }

    void show(){
        for(int i=0;i<cantidad;i++){
            for(int j=0;j<cantidad;j++){
                std::cout<<mat[i][j]<<" ";
            }std::cout<<'\n';
        }
    }
};