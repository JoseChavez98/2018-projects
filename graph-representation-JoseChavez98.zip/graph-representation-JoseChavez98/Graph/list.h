//
// Created by jose on 9/20/18.
//

#ifndef GRAPH_LIST_H
#define GRAPH_LIST_H
#include <iostream>
#include "Node.h"
#endif //GRAPH_LIST_H

template <class T>
class list{
public:
    unsigned  long  count=0;

    list() = default;
    Node <T> *head= nullptr;
    Node  <T> *tail= nullptr;

    void insert( T val){

        Node <T> *newnode;
        newnode = new Node <T> {val, nullptr};
        if(head == nullptr){
            head=newnode;
            tail=newnode;
        }
        else{
            tail->next_pointer=newnode;
            tail=newnode;

        }
    }
    unsigned long size(){
        for ( Node <T> * current = head ; current != nullptr ; current = current->next_pointer ) {
            this->count++;
        }
        return this->count;
    }
    T *conexion(unsigned long largo){
        T *arr;
        arr=new T[largo];

        auto cont=0;
        for ( Node <T> * current = head->next_pointer ; current != nullptr ; current = current->next_pointer ) {
            arr[cont]=current->val;
            cont++;
        }
        return arr;

    }
    void describe(){

        for ( Node <T> * current = head ; current != nullptr ; current = current->next_pointer ) {
            std::cout << current->val << " ";
        }
        std::cout << "\n";
    }
};

