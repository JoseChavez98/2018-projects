# Graph Representation 

## Description

1. Build a graph data structure to add nodes and vertices of *ints*

  - Using an **adjacency matrix**
  - Using an **adjacency list**
  - Using both **raw pointers** and standard template library (**STL**)
  - Print the structure in the screen
  
2. After that generalize your implementation to add custom nodes and edges.

  - Nodes of Cartesian coordinates ( pair<int,int> or custom struct ) 
  - Edges with the distance between nodes

3. Finally generalize your graph structure to support any type of node and edge (custom classes).


### Considerations

- Overload operators and streams.
- Using inheritance, function objects or function pointers.
- Raw pointers implementation means no STL.
- Use c++-17 features
