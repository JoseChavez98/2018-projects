# trie-cpp
Data structure implemented for information reTRIEval
