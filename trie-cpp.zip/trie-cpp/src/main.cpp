#include <iostream>
#include "models/Trie.h"

int main() {
  Trie<std::string, int> trie;

  trie.insert("akl", 100);
  trie.insert("br", 100);
  trie.insert("brj", 100);
  trie.insert("brmd", 100);
  trie.insert("abcd", 300);
  trie.insert("abd", 200);
  trie.insert("ab", 100);
  trie.insert("abch", 100);

  // May be empty vector
  std::vector<std::string> x = trie.reachables("a");
for(auto &i : x){
  std::cout<< i<< " ";
}
  return 0;
}
