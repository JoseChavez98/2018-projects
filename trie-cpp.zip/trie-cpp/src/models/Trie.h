#ifndef TRIE_CPP_TRIE
#define TRIE_CPP_TRIE

#include <map>
#include <vector>
#include <string>
#include <stack>
#include <iostream>

#define MAX_ELEMENTS_RETRIEVED 4

template<class Key, class AnyObject>
class Trie {
 public:
  Trie() = default;

  struct Node {
    std::map<char, Node *> children;
    AnyObject content = NULL;
    bool terminate = false;
  };

  // Root node
  Node *root = new Node();

  // Insert
  void insert(Key keys, AnyObject content) {
    Node *temp = this->root;

    for (auto key: keys) {
      if (!temp->children[key]) {
        temp->children[key] = new Node();
      }

      temp = temp->children[key];
    }

    temp->content = content;
    temp->terminate = true;
  }

  // Search
  Node *search(Key keys) {
    Node *temp = this->root;

    for (auto key : keys) {
      if (!temp->children[key]) {
        return nullptr;
      }

      temp = temp->children[key];
    }

    //return (temp->terminate ? temp : nullptr);
    return temp;
  }

  // Reachables_recursive
  void reachables_recursive(Node *node, std::vector<Key> &reachablesWord, Key keys) {
    // Send word to the vector
    if (this->isTerminate(node)) {
      reachablesWord.push_back(keys);
    }

    if (this->isLeaf(node)) {
      return;
    }

    for (auto child : node->children) {
      if (reachablesWord.size() >= MAX_ELEMENTS_RETRIEVED) {
        break;
      }

      // Add letter
      keys += child.first;

      // Recursive
      this->reachables_recursive(child.second, reachablesWord, keys);

      keys = keys.substr(0, keys.size() - 1);
    }
  }

  std::vector<Key> reachables(Key keys) {
    std::vector<Key> reachablesWord;

    if (keys.empty()) {
      return reachablesWord;
    }

    auto node = search(keys);

    if (node != nullptr && this->isLeaf(node)) {
      return reachablesWord;
    }

    // Node exists
    // Ya tengo mi substring inicial: keys
    this->reachables_recursive(node, reachablesWord, keys);

    return reachablesWord;
  }

  void deleteWord(Key key) {
    std::stack<Node *> stack;
    stack.push(this->root);
    while (!stack.empty()) {
      if (this->isLeaf(stack.top())) {
        if (this->isTerminate(stack.top())) {
          stack.clear();
          break;
        } else {

        };
      }
    }
  }

  // Helpers
  bool isLeaf(Node *node) {
    return node->children.empty();
  }

  bool isTerminate(Node *node) {
    return node->terminate;
  }
};

#endif
