//
// Created by jose on 11/15/18.
//

#ifndef THREADS_JOSECHAVEZ98_PARALELL_VECTOR_H
#define THREADS_JOSECHAVEZ98_PARALELL_VECTOR_H

#include <iostream>
#include <vector>
#include <limits>
#include <random>
#include <functional>
#include <mutex>
#include "thread_control.h"

std::mutex m;

class ParallelVector {
  int *vec =new int [4];
 public:
  ParallelVector() {
    ThreadControl<int> threads;

    std::function<void(std::mutex &)> f = [&](std::mutex &a) {
      std::lock_guard<std::mutex> guard(a);
      const unsigned int seed = time(0);
      std::mt19937_64 rng(seed);
      std::uniform_int_distribution<int> unii(1,2);

      for (int i = 0; i < 4; i++) {
        *(vec+i)=unii(rng);
        }
    };

    threads.deploy_threads_void_void(f, m);
  }
  int search(int num){
    ThreadControl<int> threads;
    std::promise<int>  promise;
    std::function<int(int& ,std::mutex &,std::promise<int> *)> f = [&]( int &numero,std::mutex&a,std::promise<int> * promObj){
      std::lock_guard<std::mutex> guard(a);
      for(int i=0; i<4 ;++i){
        std::cout<<this->vec[i]<<" ";
       if(this->vec[i]==num){
         promObj->set_value(num);
         promise=promObj;
         
       }else{
         continue;
       }

      }promObj->set_value(0);
         promise=promObj;
      

    };

    threads.deploy_threads_int_int(f,num,m,&promise);
  }
  int *get_vector() {
    return this->vec;
  }
};

#endif //THREADS_JOSECHAVEZ98_PARALELL_VECTOR_H