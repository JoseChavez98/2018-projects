# Threading in C++
Threads practice in C++

## Today's Lecture

Today's activity is about implementing a some parallel algorithms using standard C++ threads library (`#include <thread>`). This includes the following topics:

- [ ] Threads creation
  - Function pointers
  - Lambdas/closures
- [ ] Threads synchronization
  - Mutex
  - Guard lock

## Parallel Vector

Implement a generic vector that implements the following parallel functions:

```c++

typedef ParallelVector<int> Vector;

Vector vector(...);

std::cout << vector.search(2) << "\n";
std::cout << vector.min_element() << "\n";
std::cout << vector.max_element() << "\n";
std::cout << vector.accumulate() << "\n"; // sum of elements

```

Use the `std::numeric_limits<T>::min()` and `std::numeric_limits<int>::max()` functions to populate a sufficiently large vector.

Perform a set of experiments to measure the execution times of the search and min/max functions in both linear and parallel versions. You can use a vector with sizes of (10^k), 2 <= k <= 12.


## Parallel Matrix

Implement a Parallel Matrix structure that handles the following operations:

```c++

Matrix u(3,4);
Matrix v(4,3);
Matrix w(1,3);

auto a = u + v; // sum of matrices
auto b = (a * v) * w; // matrices multiplication
auto c = b * 2; // matrix multiplied by constant
auto d = u - v; // substraction of matrices

a.transpose().display();  // matrix transpose and print

```

## Homework

- Parallel Quicksort

