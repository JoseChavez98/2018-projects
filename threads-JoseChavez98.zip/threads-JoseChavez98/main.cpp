#include <iostream>
#include "paralell_vector.h"

int main() {
  ParallelVector  a;
  //auto vec=a.get_vector();
  //std::cout<<vec[9]<<'\n';
  a.search(5);



  return 0;
}
