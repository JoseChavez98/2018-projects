//
// Created by jose on 11/15/18.
//

#ifndef THREADS_JOSECHAVEZ98_THREADCONTROL_H
#define THREADS_JOSECHAVEZ98_THREADCONTROL_H

#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <functional>
#include <future>

const int NUMBER_THREADS = 4;

template<class T>
class ThreadControl {
 private:
  std::thread threads[NUMBER_THREADS] ;
 public:
  ThreadControl() = default;

  void deploy_threads_void_void(std::function<void(std::mutex&)> &f, std::mutex &x) {
    for (int i = 0; i < NUMBER_THREADS; i++) {
      this->threads[i] = std::thread(f, std::ref(x));
    }

    for (auto &i : this->threads) {
      i.join();
    }
  }
  void deploy_threads_int_int(std::function<int(int&,std::mutex&)> &f,int &num ,std::mutex &x,std::promise<int> * promObj){
    std::future<int> futureObj = promObj->get_future();
    for (int i = 0; i < NUMBER_THREADS; i++) {
      this->threads[i] = std::thread(f,std::ref(num), std::ref(x), std::ref(promObj));
      if(futureObj.get()){
        std::cout<< futureObj.get();
        
      }
    }

    for (auto &i : this->threads) {
      i.join();
    }
  }
};

#endif //THREADS_JOSECHAVEZ98_THREADCONTROL_H