//
//  main.cpp
//  Facebook Iterator
//
//  Created by Bryan Gonzales Vega on 9/5/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#include <iostream>
#include "facebook.hpp"

int main(int argc, const char * argv[]) {
    const std::string facebook_access_token = "EAAJn30QuZAsoBAMnYdemZC6SCy84vHV7enxEDEK4xikhPCqg2pvR6bSpSu6CrlIFvFS3IxbrZBBLcIKPwdJVk4MDe90CBDGm7k1oz89EGieMpbqholRAgaXek4QCQt7hJmtVuYD30mZAKNpO23GWA5Ho3r1M23gZD";

    auto posts = facebook_liked_posts( facebook_access_token );

    for ( const auto &[key, value] : posts ) {
        std::cout << value << std::endl;
    }
    
    return 0;
}
