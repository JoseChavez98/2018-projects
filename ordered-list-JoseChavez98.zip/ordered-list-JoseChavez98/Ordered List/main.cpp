//
//  main.cpp
//  Ordered List
//
//  Created by Bryan Gonzales Vega on 9/5/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#include "orderedList.hpp"

int main() {
    
    OrderedList<int> list;
    list.insert(3);    list.insert(6);list.insert(5);list.insert(4);list.insert(-2);
    OrderedList<int>::ForwardIterator it{};
    for(it=list.begin();it!=list.end();++it){
        std::cout<<(*it)<<" ";
    }


    /* 2) Implement Forward Iterator STL-style */

    /* 3) Implement Reverse Iterator STL-style */
    
    return 0;
}
