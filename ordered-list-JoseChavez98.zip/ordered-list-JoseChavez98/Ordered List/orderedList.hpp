//
//  orderedList.hpp
//  Ordered List
//
//  Created by Bryan Gonzales Vega on 9/5/18.
//  Copyright © 2018 UTEC. All rights reserved.
//
#include<iostream>
#ifndef orderedList_h
#define orderedList_h

template <class T>
class ForwardIterator;

template<class T>

class OrderedList {


public:
    typedef ::ForwardIterator<T>ForwardIterator;

    struct Node{
        T value;

        Node *next_pointer;


    };
    Node *head= nullptr;

    OrderedList() = default;



    bool find (T target, Node **& pointer) {
        while ((*pointer) && (*pointer)->value <= target) {
            if ((*pointer)->value == target) {
                return true;
            }
            pointer = &((*pointer)->next_pointer);
        }
        return false;
    }

    void insert(T val) {
        Node **pointer=&head;
        if(!find(val,pointer)){
        auto newnode = new Node{val,(*pointer)};
            (*pointer)=newnode;
        }
    }

void describe(){


    for(Node *current=head;current!= nullptr;current=current->next_pointer){
        std::cout<<current->value<<"  ";
    }
}
   ForwardIterator begin(){
       ForwardIterator r(head);
       return r;


    }
    ForwardIterator end(){
        /*for(Node *current=head;current!= nullptr;current=current->next_pointer){
            std::cout<<current->value<<"  ";
        }*/

        ForwardIterator r(nullptr);
        return r;
    }
};

template <class T>
class ForwardIterator {
private:
    typedef typename OrderedList<T>::Node   Node;
    Node *current;
public:
     ForwardIterator(Node *node){
        this->current=node;
}
    ForwardIterator()= default;

    T operator *(){
        return current->value;
    }

    bool operator !=(ForwardIterator other){
        auto r=current->value!=other.current->value;
        return !(r);
    }
    T operator ++(){
        this->current=this->current->next_pointer;
        return *this;
    }
};


#endif /* orderedList_h */
