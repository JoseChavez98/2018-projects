//
//  ordered_list.h
//  Function Objects
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#ifndef ordered_list_h
#define ordered_list_h

template <class T>
class OrderedList {
public:
    OrderedList() = default;
    
    void insert(T) { /* ... */ }
    void remove(T) { /* ... */ }
};

#endif /* ordered_list_h */
