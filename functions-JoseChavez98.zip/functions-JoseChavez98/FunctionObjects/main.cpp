//
//  main.cpp
//  Function Objects
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#include "../libs/facebook.hpp"
#include "ordered_list.h"
#include "unit_test.hpp"

int main() {
    
    /* Configuration parameters */
    
    const std::string project_path = "<PATH>/"; // Repository path ( with a '/' in the end )
    const std::string access_token = "<ACCESS_TOKEN>";
    
    
    /* Ordered List */
    
    auto unordered_posts = facebook_liked_posts( access_token );
    
    OrderedList<Post> unordered_posts_list;
    
    for ( const auto &[id, post] : unordered_posts ) {
        unordered_posts_list.insert(post);
    }
    
    
    /* Run tests and plot execution times */
    
//    Testable::run(project_path, unit_tests, TestLevel::easy);
//    Testable::run(project_path, unit_tests, TestLevel::tricky);
    
    return 0;
}
