//
//  facebook.h
//  Facebook Iterator
//
//  Created by Bryan Gonzales Vega on 9/5/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#ifndef facebook_h
#define facebook_h

#include <iostream>
#include <string>
#include <ctime>
#include "json.hpp"
#include <curl/curl.h>
#include <map>
#include "post.hpp"

using json = nlohmann::json;

size_t writeFunction(void *ptr, size_t size, size_t nmemb, std::string* data) {
    data->append((char*) ptr, size * nmemb);
    return size * nmemb;
}

FacebookPosts facebook_liked_posts(const std::string access_token){
    auto curl = curl_easy_init();
    if (curl) {
        const std::string facebook_graph_api = "https://graph.facebook.com/v3.1/me?&date_format=U&access_token=" + access_token + "&fields=name,likes.order(chronological).limit(300)";
        curl_easy_setopt(curl, CURLOPT_URL, facebook_graph_api.c_str());
        
        std::string response_string;
        std::string header_string;
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeFunction);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_string);
        curl_easy_setopt(curl, CURLOPT_HEADERDATA, &header_string);
        
        char* url;
        long response_code;
        double elapsed;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME, &elapsed);
        curl_easy_getinfo(curl, CURLINFO_EFFECTIVE_URL, &url);
        
        curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        curl = NULL;

        FacebookPosts facebook_posts;
        auto content = json::parse(response_string);

        for ( auto item : content["likes"]["data"] ) {
            if (item["created_time"].is_number() && item["id"].is_string() && item["name"].is_string() ) {
                std::string post_id     = item["id"];
                std::string name        = item["name"];
                std::time_t timestamp   = item["created_time"];
                facebook_posts[post_id] = {name, timestamp};
            }
        }
        
        return facebook_posts;
    }

    return FacebookPosts();
}

#endif /* facebook_h */
