//
//  facebookPost.hpp
//  Facebook Iterator
//
//  Created by Bryan Gonzales Vega on 9/5/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#ifndef facebookPost_h
#define facebookPost_h

#include <iostream>
#include <unordered_map>
#include <ostream>

struct Post {
    std::string title;
    std::time_t timestamp;
};

typedef std::map<std::string, Post> FacebookPosts;


/* Helper functions */

std::string timestamp_to_human(time_t epoch, const char* format = "%Y-%m-%d %H:%M:%S") {
    char timestamp[64] = {0};
    strftime(timestamp, sizeof(timestamp), format, localtime(&epoch));
    return timestamp;
}

std::ostream& operator << (std::ostream &os, const Post &post) {
    os << timestamp_to_human(post.timestamp) << " \t" << post.title;
    return os;
}

#endif /* facebookPost_h */
