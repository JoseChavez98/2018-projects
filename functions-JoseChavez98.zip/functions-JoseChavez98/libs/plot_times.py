import sys
import matplotlib.pyplot as plt

def read_integers(filename):
    arr = []
    with open(filename) as file:
        for line in file.readlines():
            for i in line.split():
                arr.append(float(i))
    return arr

if len(sys.argv) - 1 < 1 :
    print("Missing file name !! ")
    exit(0)

#a = read_integers( sys.argv[1] )
plt.plot(read_integers( sys.argv[1] ))
plt.ylabel('Time')
plt.show()
