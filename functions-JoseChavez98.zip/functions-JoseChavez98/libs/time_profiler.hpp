//
//  time_profiles.hpp
//  Functions
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#ifndef time_profiles_h
#define time_profiles_h

// Basic usage:
// Profile<>::time("Process name", "/path/to/output/file", [&](){
// });

#include <string>
#include <chrono>
#include <fstream>

template <typename TimeObject = std::chrono::milliseconds>
struct Profile {
    
    template <typename Function, typename ...Arguments>
    static double time(std::string filename, Function && func, Arguments &&... args){
        std::ofstream os;
        os.open(filename, std::ofstream::out | std::ofstream::app);

        auto start  = std::chrono::steady_clock::now();
        std::forward<decltype(func)>(func)(std::forward<Arguments>(args)...);
        auto end    = std::chrono::steady_clock::now();
        auto duration = std::chrono::duration_cast<TimeObject>(end-start).count();
        
        // printf("%.3f\n", duration * 0.001 );
        os << (double)duration * 0.001 << "\n";
        os.close();
        return (double)duration * 0.001;
    }
    
    static void reset ( std::string filename ){
        std::remove(filename.c_str());
    }
};

#endif /* time_profiles_h */
