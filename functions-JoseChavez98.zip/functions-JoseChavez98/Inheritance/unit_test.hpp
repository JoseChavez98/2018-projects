//
//  unit_test.h
//  Inheritance
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#ifndef unit_test_h
#define unit_test_h

#include "../libs/testable.hpp"
#include "../libs/time_profiler.hpp"
#include <limits>

const std::string project_name = "Inheritance";

TestCases unit_tests = {
    {
        TestLevel::easy, [] (std::string project_path) {
            std::string filename = project_path + project_name + "/times.txt";
            
            OrderedList<uint8_t> list;
            
            Profile<>::reset(filename);
            for (uint8_t i = std::numeric_limits<uint8_t>::max(); i != std::numeric_limits<uint8_t>::min() ; i--){
                Profile<>::time(filename, [&](){
                    list.insert(i);
                });
            }
            
            const std::string python_times_path = project_path + "libs/plot_times.py";
            const std::string times_result_path = project_path + project_name + "/times.txt";
            const std::string command = "python " + python_times_path + " " + times_result_path;

            system(command.c_str());
        }
    },{
        TestLevel::tricky, [] (std::string project_path) {
            std::string filename = project_path + project_name + "/times.txt";
            
            OrderedList<uint16_t> list;
            
            Profile<>::reset(filename);
            for (uint16_t i = std::numeric_limits<uint16_t>::max(); i != std::numeric_limits<uint16_t>::min() ; i--){
                Profile<>::time(filename, [&](){
                    list.insert(i);
                });
            }
            
            const std::string python_times_path = project_path + "libs/plot_times.py";
            const std::string times_result_path = project_path + project_name + "/times.txt";
            const std::string command = "python " + python_times_path + " " + times_result_path;
            
            system(command.c_str());
        }
    }
};

#endif /* unit_test_h */
