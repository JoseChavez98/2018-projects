//
//  ordered_list.h
//  Inheritance
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
#include <iostream>
#ifndef ordered_list_h
#define ordered_list_h









template <class T>
struct Node{
    T value;
    Node *next_pointer;
};
template <class T>
class choice{
private:
    Node<T> *pointer= nullptr;
    T target;
public:
    bool result(){
        return this->*pointer->value <= this->target();
    }
};
template <class T>
class OrderedList {
public:

    Node<T> *head= nullptr;
    OrderedList() = default;
    bool find (T target, Node<T> **& pointer) {
        while ((*pointer) && (*pointer)->value <= target) {
            if ((*pointer)->value == target) {
                return true;
            }
            pointer = &((*pointer)->next_pointer);
        }
        return false;
    }
    void insert(T val) { Node **pointer=&head;
        if(!find(val,pointer)){
            auto newnode = new Node{val,(*pointer)};
            (*pointer)=newnode;
        } }
    void remove(T val) {
        Node **pointer=&head;
        if(find(val,pointer)){

        }
    }
    void describe(){


        for(Node *current=head;current!= nullptr;current=current->next_pointer){
            std::cout<<current->value<<"  ";
        }}
};


#endif /* ordered_list_h */
