//
//  main.cpp
//  Inheritance
//
//  Created by Bryan Gonzales Vega on 9/12/18.
//  Copyright © 2018 UTEC. All rights reserved.
//

#include "../libs/facebook.hpp"
#include "ordered_list.h"
#include "unit_test.hpp"

int main() {
    
    /* Configuration parameters */
    
    const std::string project_path = "/home/jose/CLionProjects/functions-JoseChavez98/"; // Repository path ( with a '/' in the end )
    const std::string access_token = "EAAJn30QuZAsoBAMnYdemZC6SCy84vHV7enxEDEK4xikhPCqg2pvR6bSpSu6CrlIFvFS3IxbrZBBLcIKPwdJVk4MDe90CBDGm7k1oz89EGieMpbqholRAgaXek4QCQt7hJmtVuYD30mZAKNpO23GWA5Ho3r1M23gZD";
    
    
    /* Ordered List */
    
    auto unordered_posts = facebook_liked_posts( access_token );
    
    OrderedList<int> unordered_posts_list;
    
 /*   for ( const auto &[id, post] : unordered_posts ) {
        unordered_posts_list.insert(post);
    }
*/
  unordered_posts_list.insert(1);
    unordered_posts_list.insert(3);
    unordered_posts_list.insert(-2);
    unordered_posts_list.insert(1);
    unordered_posts_list.describe();
    /* Run tests and plot execution times */

//        Testable::run(project_path, unit_tests, TestLevel::easy);
//    Testable::run(project_path, unit_tests, TestLevel::tricky);
    
    return 0;
}
