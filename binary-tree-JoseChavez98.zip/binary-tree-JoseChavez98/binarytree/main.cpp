#include <iostream>
template <class T>
class binarytree{
public:
    struct Node{
        T value;
        Node *left_pointer;
        Node *right_pointer;

    };
    Node *root= nullptr;
    binarytree()=default;
    bool find(T target , Node **& ptr){
        while(*ptr != nullptr){
            if(target==(*ptr)->value){
                return true;
            }
            else if(target > (*ptr)->value){
                ptr=&((*ptr)->right_pointer);
            }
            else{
                ptr=&((*ptr)->left_pointer);
            }

        }return false;
    }
    void insert(T val){
        Node **p= &root;
        if(!find(val,p)){
            auto *newnode= new Node{val, nullptr, nullptr};
            *p=newnode;
        }
    }

    void inorder_print(Node *p){
        if(p==nullptr)return;
        inorder_print(p->left_pointer);
        std::cout<<p->value<<" ";
        inorder_print(p->right_pointer);
    }

};
int main() {
 binarytree<int> k;
    k.insert(12);k.insert(6);k.insert(15);k.insert(23);k.insert(32);k.insert(7);k.insert(11);
    k.inorder_print(k.root);
    //std::cout<<k.root->value;
    return 0;
}