# Binary Tree

For this exercise you need to implement a binary tree data structure with the folowing methods:

- Insert a value
- Depth tree traversals (inorder, preorder, postorder)
- Breadth tree traversal


